# -*- coding:utf-8-*-
import pandas as pd


dataset = pd.read_csv("for_count.csv")
dataset.columns = ['date','data']


'''

extract features

'''

dataset['max_of_30day'] = None
dataset['min_of_30day'] = None
dataset['use_after30days'] = None

for i in range(len(dataset)-30):#对数据进行处理
    dataset['max_of_30day'][i+30] = max(dataset['data'][i:i+30])#找出前30天最大值。
    dataset['min_of_30day'][i+30] = min(dataset['data'][i:i+30])#找出前30天最小值
    dataset['use_after30days'][i]=dataset['data'][i+30]#找出30天后的用电量

#dataset = dataset.dropna()   #去掉前30个和后30个无效的数据。
'''
lables_raw = dataset['use_after30days'] #提取出需要预测的数据
lables = dataset['use_after30days'] > dataset['data'] #为分类处理数据，判断30天后的用电量是否大于今日用电量
lables_ud = lables.replace({True:'up',False:'down'}) #方便他人阅读，将True和False改为up和down，意味着30天后用电量涨了还是跌了
features = dataset.drop(['use_after30days'],axis = 1) #在特征值中去掉我们要预测的数据。
'''
#print(dataset)
dataset.to_csv("features.csv",index=None)
